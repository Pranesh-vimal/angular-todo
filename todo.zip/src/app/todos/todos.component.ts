import { Component, OnInit } from '@angular/core';
import { Todo } from '../Todo';

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.scss'],
})
export class TodosComponent implements OnInit {
  todo: string = '';

  todos: Todo[] = [];

  constructor() {}

  ngOnInit(): void {}

  addTodo(): void {
    if (this.todo.length == 0) {
      return;
    }

    this.todos.push({
      id: this.todos.length + 1,
      title: this.todo,
      completed: false,
    });

    this.todo = '';
  }

  changeStatus(id: Object): void {
    this.todos.map((todo) => {
      if (todo.id === id) {
        todo.completed = !todo.completed;
      }
    });
  }

  deleteTodo(id: Number): void {
    this.todos = this.todos.filter((todo: Todo) => todo.id !== id);
  }
}
